import sys

from pyfiglet import main

"""

Run either as:

from extermal directory:
  python <pyfiglet-path>/pyfiglet/__main__.py [args]

from anywhere, as long as pyfiglet is on python's python path:
  python -m pyfiglet [args]

"""

if __name__ == '__main__':
    sys.exit(main())
